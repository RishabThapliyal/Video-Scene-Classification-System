import React from "react";
import { Link } from "react-router-dom";

function Home() {
  const features = [
    {
      title: "📤 Upload Videos",
      description: "Upload your videos for automatic scene classification.",
    },
    {
      title: "🎬 Scene Detection",
      description: "AI detects key scenes for easier organization.",
    },
    {
      title: "🗂 Manage Files",
      description: "Delete or organize videos efficiently.",
    },
    {
      title: "🔍 Advanced Search",
      description: "Search for specific scenes using keywords or timestamps.",
    },
    {
      title: "📊 Analytics",
      description: "View detailed analytics for your videos and scenes.",
    },
    {
      title: "🌐 Multi-Platform Support",
      description: "Access your videos from any device, anywhere.",
    },
  ];

  return (
    <div className="container text-center">
      <section className="my-5 py-5 bg-light rounded animate__animated animate__fadeIn">
        <h2>Welcome to Video Scene Classification</h2>
        <p className="lead">Upload videos, define scenes, and manage your content easily.</p>
        <Link className="btn btn-primary btn-lg btn-hover-animate" to="/upload">
          Search Scene
        </Link>
      </section>
      <section className="row mt-5">
        {features.map((feature, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div
              className="card h-100 shadow-sm animate__animated animate__fadeInUp"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="card-body">
                <h4 className="card-title">{feature.title}</h4>
                <p className="card-text">{feature.description}</p>
              </div>
            </div>
          </div>
        ))}
      </section>

        <section className="row mt-5">
        <h2 className="mb-4">What Our Users Say</h2>
        {[
          {
            quote: "This app has revolutionized how I manage my video content!",
            author: "John",
          },
          {
            quote: "The scene detection feature is incredibly accurate and saves me so much time.",
            author: "Amy",
          },
          {
            quote: "I love the intuitive interface and powerful features.",
            author: "Sam",
          },
        ].map((testimonial, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card h-100 shadow-sm animate__animated animate__fadeInUp">
              <div className="card-body">
                <blockquote className="blockquote mb-0">
                  <p>{testimonial.quote}</p>
                  <footer className="blockquote-footer">
                    <cite>{testimonial.author}</cite>
                  </footer>
                </blockquote>
              </div>
            </div>
          </div>
        ))}
      </section>  
    </div>
  );
}

export default Home;