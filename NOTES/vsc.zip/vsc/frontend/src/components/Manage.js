import React from "react";

function Manage() {
  return (
    <div className="container text-center my-5">
      <h2>Manage Your Videos</h2>
      <p className="lead">Here you can delete or organize your uploaded videos.</p>
      <div className="mt-4">
        <p className="text-muted">(Feature coming soon!)</p>
      </div>
    </div>
  );
}

export default Manage;