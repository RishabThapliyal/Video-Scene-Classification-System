import React, { useState } from "react";

function FAQ() {
  const faqs = [
    {
      question: "How do I upload a video?",
      answer: "Click on the 'Search Scene' button and select your video file.",
    },
    {
      question: "What video formats are supported?",
      answer: "It supports MP4, AVI, MOV and many other formats.",
    },
    {
      question: "Can I delete uploaded videos?",
      answer: "Yes, you can manage and delete videos in the 'Manage' section.",
    },
  ];

  const [activeIndex, setActiveIndex] = useState(null);

  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="container text-center my-5 ">
      <h2 className="mb-4">Frequently Asked Questions</h2>
      <div className="row justify-content-center">
        {faqs.map((faq, index) => (
          <div key={index} className="col-md-8 mb-3">
            <div
              className="card p-3 shadow-sm hover-effect"
              onClick={() => toggleFAQ(index)}
              style={{ cursor: "pointer" }}
            >
              <h5 className="card-title">{faq.question}</h5>
              {activeIndex === index && (
                <p className="card-text mt-3">{faq.answer}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FAQ;