import React, { useState, useRef } from "react";

function Upload() {
  const [file, setFile] = useState(null);
  const [sceneDescription, setSceneDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [resultTimestamp, setResultTimestamp] = useState(null);
  const [error, setError] = useState(null);

  const videoRef = useRef(null);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.type.startsWith("video/")) {
      setFile(selectedFile);
      setResultTimestamp(null);
      setError(null);

      if (videoRef.current) {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
        videoRef.current.load();
      }

    } else {
      alert("Please select a valid video file.");
      setFile(null);
    }
  };

  const handleDescriptionChange = (event) => {
    setSceneDescription(event.target.value);
  };

  const handleSearchScene = async () => {
    if (!file) {
      alert("Please select a video file.");
      return;
    }
    if (!sceneDescription) {
      alert("Please enter a scene description.");
      return;
    }

    setLoading(true);
    setResultTimestamp(null);
    setError(null);

    const formData = new FormData();
    formData.append("video", file);
    formData.append("sceneDescription", sceneDescription);

    try {
      const response = await fetch("http://127.0.0.1:5000/process_video", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        setResultTimestamp(data.timestamp);
        console.log("Scene search successful:", data.message, "Timestamp:", data.timestamp);

        if (videoRef.current && data.timestamp) {
            const parts = data.timestamp.split(':').map(Number);
            const totalSeconds = parts[0] * 3600 + parts[1] * 60 + parts[2];

            videoRef.current.currentTime = totalSeconds;
            videoRef.current.play();
        }

      } else {
        setError(data.error || "An unknown error occurred during scene search.");
        console.error("Scene search failed:", data.error);
      }
    } catch (err) {
      setError("Failed to connect to the server. Please ensure the backend is running and accessible.");
      console.error("Error connecting to backend:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container text-center my-5 animate__animated animate__fadeIn">
      <h2>Search Scene in Your Video</h2>
      <div className="mt-4">
        <input
          type="file"
          className="form-control"
          onChange={handleFileChange}
          accept="video/*"
        />
      </div>
      {file && (
        <div className="mt-4 animate__animated animate__fadeInUp ">
          <h5>Selected Video:</h5>
          <video controls className="w-100 rounded shadow-sm" ref={videoRef}>
            {/* The src will dynamically update as 'file' state changes */}
            <source src={URL.createObjectURL(file)} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="mt-3">
            <label htmlFor="sceneDescription">Define the Scene:</label>
            <textarea
              id="sceneDescription"
              className="form-control"
              rows="3"
              placeholder="Enter scene description, e.g., 'A person riding a bicycle on a street'"
              value={sceneDescription}
              onChange={handleDescriptionChange}
            />
          </div>
        </div>
      )}
      <button
        className="btn btn-primary mt-4 slide-in-right"
        onClick={handleSearchScene}
        disabled={loading || !file || !sceneDescription}
      >
        {loading ? "Searching..." : "Search Scene"}
      </button>

      {loading && (
        <div className="alert alert-info mt-3 animate__animated animate__fadeIn">
          Processing your video. This may take some time depending on video length and complexity...
        </div>
      )}
      {resultTimestamp && (
        <div className="alert alert-success mt-3 animate__animated animate__fadeIn">
          Found matching scene at timestamp: <strong>{resultTimestamp}</strong>
        </div>
      )}
      {error && (
        <div className="alert alert-danger mt-3 animate__animated animate__fadeIn">
          Error: {error}
        </div>
      )}
    </div>
  );
}

export default Upload;