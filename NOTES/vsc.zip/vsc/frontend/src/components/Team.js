import React, { useState } from "react";
import "./Team.css"; // Import Team.css

function Team() {
  const teamMembers = [
    { name: "Rishab Thapliyal", role: "2119013", description: "..." },
    { name: "Vimal Singh Panwar", role: "2119423", description: "..." },
    { name: "Yugraj", role: "2119460", description: "..." },
    { name: "Shubham Singh Karki", role: "2119234", description: "..." },
  ];

  const [selectedMember, setSelectedMember] = useState(null);

  return (
    <div className="container text-center my-5 team-container">
      <h2 className="mb-4 animate__animated animate__fadeIn">Meet Our Team</h2>
      <div className="row justify-content-center">
        {teamMembers.map((member, index) => (
          <div key={index} className="col-md-3 col-sm-6 my-3">
            <div
              className="card p-3 shadow-sm team-member-card animate__animated animate__fadeInUp"
              style={{ animationDelay: `${index * 0.2}s` }}
              onClick={() => setSelectedMember(member)}
            >
              <h5 className="card-title">{member.name}</h5>
              <p className="card-text text-muted">{member.role}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedMember && (
        <div className="team-member-details animate__animated animate__fadeIn">
          <button
            className="btn btn-close float-end"
            onClick={() => setSelectedMember(null)}
            aria-label="Close"
          ></button>
          <h3 className="mb-3">{selectedMember.name}</h3>
          <h5 className="text-primary">{selectedMember.role}</h5>
          <p className="lead">{selectedMember.description}</p>
        </div>
      )}
    </div>
  );
}

export default Team;