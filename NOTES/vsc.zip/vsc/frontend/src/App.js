import React, { Suspense } from "react";
import { BrowserRouter as Router, Routes, Route, NavLink } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

// Lazy load components
const Home = React.lazy(() => import("./components/Home"));
const Upload = React.lazy(() => import("./components/Upload"));
const Manage = React.lazy(() => import("./components/Manage"));
const Team = React.lazy(() => import("./components/Team"));
const NotFound = React.lazy(() => import("./components/NotFound"));
const FAQ = React.lazy(() => import("./components/FAQ"));

// Error Boundary Component
function ErrorBoundary({ children }) {
  const [hasError, setHasError] = React.useState(false);

  React.useEffect(() => {
    const errorHandler = (error) => {
      console.error(error);
      setHasError(true);
    };
    window.addEventListener("error", errorHandler);
    return () => window.removeEventListener("error", errorHandler);
  }, []);

  if (hasError) {
    return <div className="text-center">Something went wrong. Please try again later.</div>;
  }

  return children;
}

function App() {
  return (
    <Router>
      <div className="container-fluid">
        <header className="bg-primary text-white text-center py-4 animate__animated animate__fadeInDown">
          <h1>Video Scene Classification</h1>
          <nav className="mt-3">
            <NavLink className="btn btn-light m-2" to="/" end>
              Home
            </NavLink>
            <NavLink className="btn btn-light m-2" to="/upload">
              Search Scene
            </NavLink>
            <NavLink className="btn btn-light m-2" to="/manage">
              Manage
            </NavLink>
            <NavLink className="btn btn-light m-2" to="/team">
              Team
            </NavLink>
            <NavLink className="btn btn-light m-2" to="/faq">
              FAQ
            </NavLink>
          </nav>
        </header>

        <main className="container my-5">
          <ErrorBoundary>
            <Suspense fallback={<div className="text-center">Loading...</div>}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/upload" element={<Upload />} />
                <Route path="/manage" element={<Manage />} />
                <Route path="/team" element={<Team />} />
                <Route path="/faq" element={<FAQ />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </main>

        <footer className="bg-dark text-white text-center py-3 animate__animated animate__fadeInUp">
          <p>&copy; 2025 Video Scene Classification</p>
        </footer>
      </div>
    </Router>
  );
}
export default App;